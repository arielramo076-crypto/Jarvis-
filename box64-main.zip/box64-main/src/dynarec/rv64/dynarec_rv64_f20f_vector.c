// SPDX-License-Identifier: MIT
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <errno.h>

#include "debug.h"
#include "box64context.h"
#include "box64cpu.h"
#include "emu/x64emu_private.h"
#include "x64emu.h"
#include "box64stack.h"
#include "callback.h"
#include "emu/x64run_private.h"
#include "x64trace.h"
#include "dynarec_native.h"

#include "rv64_printer.h"
#include "dynarec_rv64_private.h"
#include "dynarec_rv64_functions.h"
#include "../dynarec_helper.h"

uintptr_t dynarec64_F20F_vector(dynarec_rv64_t* dyn, uintptr_t addr, uintptr_t ip, int ninst, rex_t rex, int* ok, int* need_epilog)
{
    (void)ip;
    (void)need_epilog;

    uint8_t opcode = F8;
    uint8_t nextop;
    uint8_t gd, ed;
    uint8_t wb1, wback, wb2, gback;
    uint8_t u8;
    uint64_t u64, j64;
    int v0, v1;
    int q0, q1, q2, q3, q4, q5;
    int d0, d1;
    int s0, s1;
    uint64_t tmp64u0, tmp64u1;
    int64_t fixedaddress, gdoffset;
    int unscaled;

    MAYUSE(d0);
    MAYUSE(d1);
    MAYUSE(q0);
    MAYUSE(q1);
    MAYUSE(q2);
    MAYUSE(q3);
    MAYUSE(q4);
    MAYUSE(q5);
    MAYUSE(v0);
    MAYUSE(v1);

    switch (opcode) {
        case 0x10:
            INST_NAME("MOVSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
                v0 = simd_write(dyn, ninst, x1, gd, 8, VECTOR_SEW64);
                if (v0 != v1) VMV_V_V(v0, v1);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v0 = simd_write(dyn, ninst, x1, gd, 8, VECTOR_SEW64);
                VLE_V(v0, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
                simd_commit(dyn, ninst, gd, SIMD_LO64, SIMD_HI64);
            }
            break;
        case 0x11:
            INST_NAME("MOVSD Ex, Gx");
            nextop = F8;
            GETG;
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 0);
            if (MODREG) {
                ed = (nextop & 7) + (rex.b << 3);
                v1 = simd_write(dyn, ninst, x1, ed, 8, VECTOR_SEW64);
                if (v1 != v0) VMV_V_V(v1, v0);
            } else {
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                VSE_V(v0, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
                SMWRITE2();
            }
            break;
        case 0x12:
            INST_NAME("MOVDDUP Gx, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW64);
            if (MODREG) {
                v1 = simd_get_reg(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 0, VECTOR_SEW64);
                GETGX_empty_vector(v0);
                VMV_X_S(x4, v1);
            } else {
                SMREAD();
                GETGX_empty_vector(v0);
                addr = geted(dyn, addr, ninst, nextop, &ed, x1, x2, &fixedaddress, rex, NULL, 1, 0);
                LD(x4, ed, fixedaddress);
            }
            VMV_V_X(v0, x4);
            break;
        case 0x2A:
            INST_NAME("CVTSI2SD Gx, Ed");
            nextop = F8;
            if (rex.w) {
                SET_ELEMENT_WIDTH(x3, VECTOR_SEW64);
                GETGX_vector(v0, 1, VECTOR_SEW64);
                GETED(0);
            } else {
                SET_ELEMENT_WIDTH(x3, VECTOR_SEW32);
                GETGX_vector(v0, 1, VECTOR_SEW32);
                GETED(0);
            }
            if (rex.w) {
                FCVTDL(v0, ed, BOX64ENV(dynarec_fastround) <= 1 ? RD_DYN : RD_RNE);
            } else {
                FCVTDW(v0, ed, BOX64ENV(dynarec_fastround) <= 1 ? RD_DYN : RD_RNE);
                SET_ELEMENT_WIDTH(x3, VECTOR_SEW64);
            }
            if (cpuext.xtheadvector) {
                v1 = vpu_get_scratch(dyn);
                VFMV_S_F(v1, v0);
                VECTOR_LOAD_VMASK(0b01, x4);
                VMERGE_VVM(v0, v0, v1);
            } else {
                FMVXD(x4, v0);
                VMV_S_X(v0, x4);
            }
            break;
        case 0x2C:
            INST_NAME("CVTTSD2SI Gd, Ex");
            nextop = F8;
            GETGDd;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW64);
            if (MODREG) {
                v0 = simd_get_reg(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 0, dyn->vector_eew);
            } else {
                SMREAD();
                v0 = vpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &ed, x1, x2, &fixedaddress, rex, NULL, 1, 0);
                LD(x4, ed, fixedaddress);
                VMV_S_X(v0, x4);
            }
            if (BOX64ENV(dynarec_fastround)) {
                VFMV_F_S(v0, v0);
                FCVTLDxw(gd, v0, RD_RTZ);
                if (!rex.w) ZEROUP(gd);
            } else {
                VFMV_F_S(v0, v0);
                FSFLAGSI(0); // // reset all bits
                FCVTLDxw(gd, v0, RD_RTZ);
                if (!rex.w) ZEROUP(gd);
                FRFLAGS(x5); // get back FPSR to check the IOC bit
                ANDI(x5, x5, (1 << FR_NV) | (1 << FR_OF));
                CBZ_NEXT(x5);
                if (rex.w) {
                    MOV64x(gd, 0x8000000000000000LL);
                } else {
                    MOV32w(gd, 0x80000000);
                }
            }
            break;
        case 0x2D:
            INST_NAME("CVTSD2SI Gd, Ex");
            nextop = F8;
            GETGDd;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW64);
            if (MODREG) {
                v0 = simd_get_reg(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 0, dyn->vector_eew);
            } else {
                SMREAD();
                v0 = vpu_get_scratch(dyn);
                addr = geted(dyn, addr, ninst, nextop, &ed, x1, x2, &fixedaddress, rex, NULL, 1, 0);
                LD(x4, ed, fixedaddress);
                VMV_S_X(v0, x4);
            }
            if (BOX64ENV(dynarec_fastround)) {
                VFMV_F_S(v0, v0);
                FCVTLDxw(gd, v0, RD_DYN);
                if (!rex.w) ZEROUP(gd);
            } else {
                VFMV_F_S(v0, v0);
                FSFLAGSI(0); // // reset all bits
                FCVTLDxw(gd, v0, RD_DYN);
                if (!rex.w) ZEROUP(gd);
                FRFLAGS(x5); // get back FPSR to check the IOC bit
                ANDI(x5, x5, (1 << FR_NV) | (1 << FR_OF));
                CBZ_NEXT(x5);
                if (rex.w) {
                    MOV64x(gd, 0x8000000000000000LL);
                } else {
                    MOV32w(gd, 0x80000000);
                }
            }
            break;
        case 0x38:
            return 0;
        case 0x51:
            INST_NAME("SQRTSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_write(dyn, ninst, x1, gd, 8, VECTOR_SEW64);
            simd_scalar_arith(dyn, ninst, x1, v0, v1, v1, VECTOR_SEW64, 0x51);
            break;
        case 0x58:
            INST_NAME("ADDSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 1);
            simd_scalar_arith(dyn, ninst, x1, v0, v0, v1, VECTOR_SEW64, 0x58);
            break;
        case 0x59:
            INST_NAME("MULSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 1);
            simd_scalar_arith(dyn, ninst, x1, v0, v0, v1, VECTOR_SEW64, 0x59);
            break;
        case 0x5A:
            if (!BOX64ENV(dynarec_fastnan)) return 0;
            INST_NAME("CVTSD2SS Gx, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW64);
            if (MODREG) {
                GETGX_vector(v0, 1, VECTOR_SEW64);
                v1 = simd_get_reg(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 0, VECTOR_SEW64);
            } else {
                SMREAD();
                v1 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
                addr = geted(dyn, addr, ninst, nextop, &ed, x1, x2, &fixedaddress, rex, NULL, 1, 0);
                LD(x4, ed, fixedaddress);
                VMV_S_X(v1, x4);
                GETGX_vector(v0, 1, VECTOR_SEW64);
            }
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW32);
            VECTOR_LOAD_VMASK(0b0001, x4);
            if (v1 & 1 || v0 == v1 + 1) {
                d1 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
                VMV_V_V(d1, v1);
                if (cpuext.xtheadvector) {
                    d0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
                    VFNCVT_F_F_W(d0, d1, VECTOR_MASKED);
                    VMERGE_VVM(v0, v0, d0); // implies VMASK
                } else {
                    VFNCVT_F_F_W(v0, d1, VECTOR_MASKED);
                }
            } else {
                if (cpuext.xtheadvector) {
                    d0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
                    VFNCVT_F_F_W(d0, v1, VECTOR_MASKED);
                    VMERGE_VVM(v0, v0, d0); // implies VMASK
                } else {
                    VFNCVT_F_F_W(v0, v1, VECTOR_MASKED);
                }
            }
            break;
        case 0x5C:
            INST_NAME("SUBSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 1);
            simd_scalar_arith(dyn, ninst, x1, v0, v0, v1, VECTOR_SEW64, 0x5c);
            break;
        case 0x5D:
            INST_NAME("MINSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 1);
            VMFLT_VV(VMASK, v0, v1, VECTOR_UNMASKED);
            VMERGE_VVM(v0, v1, v0);
            break;
        case 0x5E:
            INST_NAME("DIVSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 1);
            simd_scalar_arith(dyn, ninst, x1, v0, v0, v1, VECTOR_SEW64, 0x5e);
            break;
        case 0x5F:
            INST_NAME("MAXSD Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                v1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                v1 = vpu_get_scratch(dyn);
                rvv_set_config(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 1);
                VLE_V(v1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            v0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 1);
            VMFLT_VV(VMASK, v1, v0, VECTOR_UNMASKED);
            VMERGE_VVM(v0, v1, v0);
            break;
        case 0x70:
            INST_NAME("PSHUFLW Gx, Ex, Ib");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW16);
            GETEX_vector(v1, 0, 1, VECTOR_SEW16);
            GETGX_vector(v0, 1, VECTOR_SEW16);
            u8 = F8;
            d0 = vpu_get_scratch(dyn);
            d1 = vpu_get_scratch(dyn);
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 16);
            tmp64u0 = 0x0007000600050004ULL;
            MOV64xs(x5, tmp64u0, x3);
            VMV_S_X(d1, x5);
            tmp64u0 = ((((uint64_t)u8 >> 6) & 3) << 48) | ((((uint64_t)u8 >> 4) & 3) << 32) | (((u8 >> 2) & 3) << 16) | (u8 & 3);
            MOV64xs(x5, tmp64u0, x3);
            VSLIDE1UP_VX_SAFE(d0, d1, x5, VECTOR_UNMASKED);
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW16, VECTOR_LMUL1, 16);
            if (v0 == v1) {
                v1 = vpu_get_scratch(dyn);
                VMV_V_V(v1, v0);
            }
            VRGATHER_VV_SAFE(v0, v1, d0, VECTOR_UNMASKED);
            break;
        case 0x7C:
            if (!BOX64ENV(dynarec_fastnan)) return 0;
            INST_NAME("HADDPS Gx, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW32);
            GETGX_vector(q0, 1, VECTOR_SEW32);
            GETEX_vector(q1, 0, 0, VECTOR_SEW32);
            v0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            d1 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            d0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            VMV_V_V(v0, q0);
            if (q1 & 1) VMV_V_V(d1, q1);
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW32, VECTOR_LMUL2, 32);
            VSLIDEUP_VI_SAFE(v0, (q1 & 1) ? d1 : q1, 4, VECTOR_UNMASKED);
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW32, VECTOR_LMUL1, 16);
            ADDI(x4, xZR, 32);
            VNSRL_WX(d0, v0, xZR, VECTOR_UNMASKED);
            VNSRL_WX(d1, v0, x4, VECTOR_UNMASKED);
            VFADD_VV(q0, d1, d0, VECTOR_UNMASKED);
            break;
        case 0x7D:
            INST_NAME("HSUBPS Gx, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW32);
            GETGX_vector(q0, 1, VECTOR_SEW32);
            GETEX_vector(q1, 0, 0, VECTOR_SEW32);
            v0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            d1 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            d0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            VMV_V_V(v0, q0);
            if (q1 & 1) VMV_V_V(d1, q1);
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW32, VECTOR_LMUL2, 32);
            VSLIDEUP_VI_SAFE(v0, (q1 & 1) ? d1 : q1, 4, VECTOR_UNMASKED);
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW32, VECTOR_LMUL1, 16);
            ADDI(x4, xZR, 32);
            VNSRL_WX(d0, v0, xZR, VECTOR_UNMASKED); // first of each pair
            VNSRL_WX(d1, v0, x4, VECTOR_UNMASKED);  // second of each pair
            VFSUB_VV(q0, d0, d1, VECTOR_UNMASKED);
            if (!BOX64ENV(dynarec_fastnan)) {
                MOV32w(x5, 0x80000000);
                VMFEQ_VV(VMASK, q0, q0, VECTOR_UNMASKED);
                VMNAND_MM(VMASK, VMASK, VMASK);
                VOR_VX(q0, q0, x5, VECTOR_MASKED);
                MOV32w(x5, 0x00400000);
                VMFNE_VV(VMASK, d1, d1, VECTOR_UNMASKED); // isnan(second), on the original value
                VOR_VX(d1, d1, x5, VECTOR_UNMASKED);      // quiet(second)
                VMERGE_VVM(q0, q0, d1);                   // second is NaN -> quiet(second)
                VMFNE_VV(VMASK, d0, d0, VECTOR_UNMASKED); // isnan(first), on the original value
                VOR_VX(d0, d0, x5, VECTOR_UNMASKED);      // quiet(first)
                VMERGE_VVM(q0, q0, d0);                   // first is NaN -> quiet(first), priority
            }
            break;
        case 0xC2:
            INST_NAME("CMPSD Gx, Ex, Ib");
            nextop = F8;
            gd = ((nextop >> 3) & 7) + (rex.r << 3);
            d0 = simd_get(dyn, ninst, x1, gd, 8, VECTOR_SEW64, 0);
            if (MODREG) {
                d1 = simd_get(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 8, VECTOR_SEW64, 0);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 1);
                d1 = vpu_get_scratch(dyn);
                VLE_V(d1, ed, VECTOR_SEW64, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            u8 = F8;
            v0 = simd_write(dyn, ninst, x1, gd, 8, VECTOR_SEW64);
            simd_compare(dyn, ninst, v0, d0, d1, u8 & 7);
            break;
        case 0xE6:
            INST_NAME("CVTPD2DQ Gx, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW64);
            GETEX_vector(v1, 0, 0, VECTOR_SEW64);
            GETGX_empty_vector(v0);
            if (v1 & 1) {
                d1 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
                VMV_V_V(d1, v1);
            } else {
                d1 = v1;
            }
            if (!BOX64ENV(dynarec_fastround)) FSFLAGSI(0);
            d0 = vpu_get_scratch_lmul(dyn, VECTOR_LMUL2);
            if (BOX64ENV(dynarec_fastround)) {
                rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW32, VECTOR_LMUL1, 8);
                VFNCVT_X_F_W(d0, d1, VECTOR_UNMASKED);
                q1 = d0;
            } else {
                VFCVT_X_F_V(d0, d1, VECTOR_UNMASKED);
                q0 = vpu_get_scratch(dyn);
                MOV64x(x4, (int64_t)INT32_MIN);
                VMSLT_VX(q0, d0, x4, VECTOR_UNMASKED);
                MOV64x(x4, (int64_t)INT32_MAX);
                VMSGT_VX(VMASK, d0, x4, VECTOR_UNMASKED);
                VMOR_MM(q0, q0, VMASK);
                rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW32, VECTOR_LMUL1, 8);
                q1 = vpu_get_scratch(dyn);
                VNSRL_WI(q1, d0, 0, VECTOR_UNMASKED);
                MOV32w(x4, 0x80000000);
                VMV_V_X(d0, x4);
                VMAND_MM(VMASK, q0, q0);
                VMERGE_VVM(q1, q1, d0);
                FRFLAGS(x5);
                ANDI(x5, x5, (1 << FR_NV) | (1 << FR_OF));
                BEQ_MARK(x5, xZR);
                emit_mxcsr_raise_invalid(x4);
                MARK;
            }
            rvv_set_vl_for_width(dyn, ninst, x1, VECTOR_SEW64, VECTOR_LMUL1, 16);
            if (!cpuext.xtheadvector) VXOR_VV(v0, v0, v0, VECTOR_UNMASKED);
            VMV_X_S(x4, q1);
            VMV_S_X(v0, x4);
            break;
        case 0xF0:
            INST_NAME("LDDQU Gx, Ex");
            nextop = F8;
            GETG;
            if (MODREG) {
                SET_ELEMENT_WIDTH(x1, VECTOR_SEWANY);
                ed = (nextop & 7) + (rex.b << 3);
                v1 = simd_get_reg(dyn, ninst, x1, ed, 0, dyn->vector_eew);
                v0 = simd_get_reg_empty(dyn, ninst, x1, gd);
                VMV_V_V(v0, v1);
            } else {
                SET_ELEMENT_WIDTH(x1, VECTOR_SEW8); // unaligned!
                SMREAD();
                v0 = simd_get_reg_empty(dyn, ninst, x1, gd);
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 0, 0);
                VLE_V(v0, ed, dyn->vector_eew, VECTOR_UNMASKED, VECTOR_NFIELD1);
            }
            break;
        case 0xD6:
            INST_NAME("MOVDQ2Q Gm, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW64);
            GETGM_vector(v0);
            if (MODREG) {
                v1 = simd_get_reg(dyn, ninst, x1, (nextop & 7) + (rex.b << 3), 0, VECTOR_SEW64);
                VMV_X_S(x4, v1);
            } else {
                SMREAD();
                addr = geted(dyn, addr, ninst, nextop, &ed, x2, x3, &fixedaddress, rex, NULL, 1, 1);
                LD(x4, ed, fixedaddress);
            }
            VMV_S_X(v0, x4);
            break;
        case 0xD0:
            INST_NAME("ADDSUBPS Gx, Ex");
            nextop = F8;
            SET_ELEMENT_WIDTH(x1, VECTOR_SEW32);
            GETGX_vector(v0, 1, VECTOR_SEW32);
            GETEX_vector(q0, 0, 0, VECTOR_SEW32);
            q1 = vpu_get_scratch(dyn);
            q2 = vpu_get_scratch(dyn);
            q3 = vpu_get_scratch(dyn);
            q4 = vpu_get_scratch(dyn);
            d0 = vpu_get_scratch(dyn);
            d1 = vpu_get_scratch(dyn);
            VMV_V_V(q1, v0);
            VFADD_VV(q2, q1, q0, VECTOR_UNMASKED);
            MOV32w(x4, 0x00400000);
            VOR_VX(d0, q1, x4, VECTOR_UNMASKED);
            VMFNE_VV(d1, q1, q1, VECTOR_UNMASKED);
            VMFNE_VV(q4, q0, q0, VECTOR_UNMASKED);
            VMAND_MM(VMASK, q4, q4);
            VMERGE_VVM(q2, q2, q0);
            VMAND_MM(VMASK, d1, d1);
            VMERGE_VVM(q2, q2, d0);
            VMOR_MM(q4, q4, d1);
            VMAND_MM(VMASK, q4, q4);
            VOR_VX(q2, q2, x4, VECTOR_MASKED);
            VMFNE_VV(d1, q2, q2, VECTOR_UNMASKED);
            VMNAND_MM(q4, q4, q4);
            VMAND_MM(d1, d1, q4);
            MOV32w(x4, 0xffc00000);
            VMV_V_X(d0, x4);
            VMAND_MM(VMASK, d1, d1);
            VMERGE_VVM(q2, q2, d0);
            VFSUB_VV(q3, q1, q0, VECTOR_UNMASKED);
            MOV32w(x4, 0x00400000);
            VOR_VX(d0, q1, x4, VECTOR_UNMASKED);
            VMFNE_VV(d1, q1, q1, VECTOR_UNMASKED);
            VMFNE_VV(q4, q0, q0, VECTOR_UNMASKED);
            VMAND_MM(VMASK, q4, q4);
            VMERGE_VVM(q3, q3, q0);
            VMAND_MM(VMASK, d1, d1);
            VMERGE_VVM(q3, q3, d0);
            VMOR_MM(q4, q4, d1);
            VMAND_MM(VMASK, q4, q4);
            VOR_VX(q3, q3, x4, VECTOR_MASKED);
            VMFNE_VV(d1, q3, q3, VECTOR_UNMASKED);
            VMNAND_MM(q4, q4, q4);
            VMAND_MM(d1, d1, q4);
            MOV32w(x4, 0xffc00000);
            VMV_V_X(d0, x4);
            VMAND_MM(VMASK, d1, d1);
            VMERGE_VVM(q3, q3, d0);
            VID_V(q4, VECTOR_UNMASKED);
            VAND_VI(q4, q4, 1, VECTOR_UNMASKED);
            VMSEQ_VX(VMASK, q4, xZR, VECTOR_UNMASKED);
            VMERGE_VVM(q2, q2, q3);
            VMV_V_V(v0, q2);
            break;
        default: DEFAULT_VECTOR;
    }
    return addr;
}
