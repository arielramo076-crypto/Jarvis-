// SPDX-License-Identifier: MIT
#ifndef __DYNAREC_RV64_FUNCTIONS_H__
#define __DYNAREC_RV64_FUNCTIONS_H__

#include "../dynarec_native_functions.h"

typedef struct x64emu_s x64emu_t;
typedef struct dynarec_rv64_s dynarec_rv64_t;

#define SCRATCH0 1
#define VMASK    0

int fpu_get_scratch(dynarec_rv64_t* dyn);
int vpu_get_scratch(dynarec_rv64_t* dyn);
int vpu_get_scratch_lmul(dynarec_rv64_t* dyn, int lmul);
void fpu_reset_scratch(dynarec_rv64_t* dyn);
int fpu_get_reg_x87(dynarec_rv64_t* dyn, int t, int n);
int fpu_get_reg_emm(dynarec_rv64_t* dyn, int t, int emm);
int simd_alloc_reg(dynarec_rv64_t* dyn, int t, int xmm);
void extcache_free_reg(dynarec_rv64_t* dyn, int reg);
void fpu_reset_reg(dynarec_rv64_t* dyn);

// ---- Neon cache functions
// Get type for STx
int extcache_get_st(dynarec_rv64_t* dyn, int ninst, int a);
// Get if STx is FLOAT or DOUBLE
int extcache_get_st_f(dynarec_rv64_t* dyn, int ninst, int a);
// Get if STx is FLOAT or I64
int extcache_get_st_f_i64(dynarec_rv64_t* dyn, int ninst, int a);
// Get actual type for STx
int extcache_get_current_st(dynarec_rv64_t* dyn, int ninst, int a);
// Get actual STx is FLOAT or DOUBLE
int extcache_get_current_st_f(dynarec_rv64_t* dyn, int a);
// Get actual STx is FLOAT or I64
int extcache_get_current_st_f_i64(dynarec_rv64_t* dyn, int a);
// Back-propagate a change float->double
void extcache_promote_double(dynarec_rv64_t* dyn, int ninst, int a);
// Combine and propagate if needed (pass 1 only)
int extcache_combine_st(dynarec_rv64_t* dyn, int ninst, int a, int b); // with stack current dyn->n_stack*
// Do not allow i64 type
int extcache_no_i64(dynarec_rv64_t* dyn, int ninst, int st, int a);

// FPU Cache transformation (for loops) // Specific, need to be written par backend
int fpuCacheNeedsTransform(dynarec_rv64_t* dyn, int ninst);

int rvv_needs_transform(dynarec_rv64_t* dyn, int ninst);

// Undo the changes of a extcache to get the status before the instruction
void extcacheUnwind(extcache_t* cache);
void fpu_save_and_unwind(dynarec_rv64_t* dyn, int ninst, extcache_t* cache);
void fpu_unwind_restore(dynarec_rv64_t* dyn, int ninst, extcache_t* cache);

const char* getCacheName(int t, int n);

void inst_name_pass3(dynarec_native_t* dyn, int ninst, const char* name, rex_t rex);
void print_opcode(dynarec_native_t* dyn, int ninst, uint32_t opcode);

// reset the cache
void fpu_reset(dynarec_native_t* dyn);
void fpu_reset_ninst(dynarec_native_t* dyn, int ninst);

// is st freed
int fpu_is_st_freed(dynarec_native_t* dyn, int ninst, int st);

void updateNativeFlags(dynarec_rv64_t* dyn);
void updateUpperLiveness(dynarec_rv64_t* dyn);
int isUpper32Zero(dynarec_rv64_t* dyn, int ninst, int reg);
void updateRspMerge(dynarec_rv64_t* dyn, int is32bits);
void get_free_scratch(dynarec_rv64_t* dyn, int ninst, uint8_t* tmp1, uint8_t* tmp2, uint8_t* tmp3, uint8_t s1, uint8_t s2, uint8_t s3, uint8_t s4, uint8_t s5);

#endif //__DYNAREC_RV64_FUNCTIONS_H__
