// SPDX-License-Identifier: MIT
#define INIT dyn->native_size = 0
#define ENDPREFIX                                        \
    dyn->prefixsize = dyn->native_size;                  \
    dyn->insts[ninst].address = dyn->native_size;        \
    dyn->insts[ninst].size = 0
#define FINI                                                                                                                                                   \
    if (ninst) {                                                                                                                                               \
        dyn->insts[ninst].address = (dyn->insts[ninst - 1].address + dyn->insts[ninst - 1].size);                                                              \
        dyn->insts_size += 1+((dyn->insts[ninst-1].x64.size>(dyn->insts[ninst-1].size/4))?dyn->insts[ninst-1].x64.size:(dyn->insts[ninst-1].size/4))/15;       \
    }

#define MESSAGE(A, ...) \
    do {                \
    } while (0)
#define EMIT(A)                      \
    do {                             \
        dyn->insts[ninst].size += 4; \
        dyn->native_size += 4;       \
    } while (0)
#define NEW_INST                                                                                                                                                               \
    dyn->rvv = dyn->insts[ninst].rvv_entry;                                                                                                                                    \
    if (ninst) {                                                                                                                                                               \
        dyn->insts[ninst].address = (dyn->insts[ninst - 1].address + dyn->insts[ninst - 1].size);                                                                              \
        dyn->insts_size += 1 + ((dyn->insts[ninst - 1].x64.size > (dyn->insts[ninst - 1].size / 4)) ? dyn->insts[ninst - 1].x64.size : (dyn->insts[ninst - 1].size / 4)) / 15; \
    }                                                                                                                                                                          \
    AREFLAGSNEEDED()
#define INST_EPILOG dyn->insts[ninst].rvv_exit = dyn->rvv;
#define INST_NAME(name)
#define TABLE64(A, V)                                \
    do {                                             \
        if (dyn->need_reloc && !isTable64(dyn, (V))) \
            AddRelocTable64Addr(dyn, ninst, (V), 2); \
        Table64(dyn, (V), 2);                        \
        EMIT(0);                                     \
        EMIT(0);                                     \
    } while (0)
#define TABLE64_(A, V)        \
    do {                      \
        Table64(dyn, (V), 2); \
        EMIT(0);              \
        EMIT(0);              \
    } while (0)
#define FTABLE64(A, V)               \
    do {                             \
        mmx87_regs_t v = { .d = V }; \
        Table64(dyn, v.q, 2);        \
        EMIT(0);                     \
        EMIT(0);                     \
    } while (0)
#define TABLE64C(A, V)                                       \
    do {                                                     \
        if (dyn->need_reloc && !isTable64(dyn, getConst(V))) \
            AddRelocTable64Const(dyn, ninst, (V), 2);        \
        Table64(dyn, getConst(V), 2);                        \
        EMIT(0);                                             \
        EMIT(0);                                             \
    } while (0)
#define CALLRET_RET(A)   do {                                                                                                                   \
                if((A) && (BOX64DRENV(dynarec_callret)>1) && !dyn->always_test) {                                                               \
                        dyn->callrets[dyn->callret_size].type = 0; dyn->callrets[dyn->callret_size++].offs = dyn->native_size; EMIT(ARCH_NOP);  \
                }                                                                                                                               \
        } while(0)
#define CALLRET_LOOP()   do { dyn->callrets[dyn->callret_size].type = 1; dyn->callrets[dyn->callret_size++].offs = dyn->native_size; EMIT(ARCH_NOP); } while(0)
