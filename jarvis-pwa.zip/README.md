# JARVIS (PWA, código abierto) para Moto G06

Asistente de voz con interfaz HUD (anillo de energía = batería, anillo WIFI = red).
Sin APK, sin servidores propios, sin claves. Licencia MIT.

## Instalar en el Moto G06 (opción A: GitHub Pages, gratis, recomendada)

1. Crea una cuenta en github.com y un repositorio público nuevo llamado `jarvis`.
2. Sube estos archivos: `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`.
3. En el repositorio: Settings > Pages > Branch `main` / carpeta `/ (root)` > Save.
4. Espera 1-2 minutos y abre `https://TU_USUARIO.github.io/jarvis/` en **Chrome** del teléfono.
5. Acepta el permiso del micrófono.
6. Menú de Chrome (⋮) > **Instalar app** / **Añadir a pantalla de inicio**.

## Opción B: Termux (sin internet para alojarlo)

```
pkg install python
cd /ruta/a/la/carpeta
python -m http.server 8080
```
Abre `http://localhost:8080` en Chrome (localhost cuenta como conexión segura) e instala.

## Comandos de voz

- "¿Qué hora es?", "¿Qué día es hoy?", "¿Cómo está la batería?", "Clima"
- "Abre WhatsApp / YouTube / Maps / Spotify / Gmail / Instagram…"
- "Reproduce [canción]" (YouTube), "Busca [tema]" (Google)
- "Llama al 5512345678", "Ruta a [lugar]"
- "Temporizador de 5 minutos", "Cuánto es 25 por 4", "Cuéntame un chiste"
- Botón 👂: escucha continua; di "Jarvis" + tu orden.

## Personalizar

- Más apps: edita el objeto `APPS` en `index.html`.
- Nuevos comandos: agrega un `if` en la función `handle()`.
- Colores: variables CSS al inicio (`--cy`, `--am`).

## Límites (por seguridad de Android/Chrome)

- Una PWA no puede apagar WiFi, encender la linterna ni leer notificaciones.
- No escucha con la pantalla apagada ni con la app en segundo plano.
- El reconocimiento de voz de Chrome usa el servicio de voz de Google (requiere internet).
- Si quieres control total del sistema, el siguiente paso sería una app nativa con Termux:API o Kotlin.
